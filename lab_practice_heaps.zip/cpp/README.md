Use this to test the code

```
g++ -std=c++17 -O2 driver.cpp -o test_cache
./test_cache
```