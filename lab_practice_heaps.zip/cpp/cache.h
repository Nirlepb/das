#ifndef CACHE_H
#define CACHE_H

/*
23CSE203 - Data Structures and Algorithms
Lab: Priority Cache Eviction

Implement the TODO methods below. Do not change class names, method
signatures, or attribute names -- the test file depends on them.

Page numbering: pages are numbered 0 .. M - 1. The array that backs
the cache still uses ordinary 0-indexed vectors, so every lookup
by page_number must use array[page_number].

Tie-breaking rule: when two heap entries have equal priority, compare
them as the pair (priority, page_number) -- the entry with the
SMALLER page_number is "more evictable" (compares smaller). This
makes eviction order deterministic and testable.
*/

#include <vector>
#include <utility>
#include <string>

// A node in the doubly linked list. Given -- do not modify.
struct DLLNode {
    int page_number;
    int priority;
    DLLNode* prev;
    DLLNode* next;

    DLLNode(int page_num, int prio)
        : page_number(page_num), priority(prio), prev(nullptr), next(nullptr) {}
};

/*
A plain doubly linked list. Implement insert_at_tail and remove so
that both run in O(1), given a direct node reference (no searching).
*/
class DLL {
public:
    DLLNode* head;
    DLLNode* tail;

    DLL() : head(nullptr), tail(nullptr) {}

    // Insert `node` at the tail of the list. Must run in O(1).
    void insert_at_tail(DLLNode* node) {
        // TODO: implement
    }

    /*
    Remove `node` from the list, given a direct reference to it.
    Must run in O(1). Correctly update head / tail if the removed
    node was the head or tail.
    */
    void remove(DLLNode* node) {
        // TODO: implement
    }

    /*
    Given -- returns [(page_number, priority), ...] in list order.
    Useful for debugging; the test file does not rely on this.
    */
    std::vector<std::pair<int, int>> as_list() const {
        std::vector<std::pair<int, int>> out;
        DLLNode* cur = head;
        while (cur != nullptr) {
            out.push_back({cur->page_number, cur->priority});
            cur = cur->next;
        }
        return out;
    }
};

/*
One slot of Cache::array, indexed by page_number.
Given -- do not modify.
*/
struct PageEntry {
    DLLNode* node;  // DLLNode* | nullptr
    int heap_idx;   // index into Heap::data, or -1 if absent

    PageEntry() : node(nullptr), heap_idx(-1) {}
};

/*
A min-heap over (priority, page_number) pairs, stored in self.data.
Holds a reference to Cache's array so that whenever two entries change
position (in _swap), it can update each entry's PageEntry.heap_idx
directly -- this is the ONLY place Heap is allowed to touch `array`.
*/
class Heap {
public:
    std::vector<std::pair<int, int>> data; // list of {priority, page_number}
    std::vector<PageEntry>& array;        // shared reference, NOT a copy

    Heap(std::vector<PageEntry>& arr) : array(arr) {}

    std::pair<int, int> _key(int i) const {
        return data[i];
    }

    /*
    Swap heap entries at indices i and j, and update
    array[...].heap_idx for both affected pages.
    */
    void _swap(int i, int j) {
        // TODO: implement
    }

    // Restore heap order by moving entry i upward as needed.
    void _sift_up(int i) {
        // TODO: implement
    }

    // Restore heap order by moving entry i downward as needed.
    void _sift_down(int i) {
        // TODO: implement
    }

    /*
    Insert a new (priority, page_number) entry, and set
    array[page_number].heap_idx accordingly.
    */
    void push(int page_number, int priority) {
        // TODO: implement
    }

    /*
    Remove and return (priority, page_number) at the root.
    Whatever entry moves into the vacated slot must have its
    heap_idx corrected. Assumes the heap is non-empty.
    */
    std::pair<int, int> pop_min() {
        // TODO: implement
        return {-1, -1};
    }

    /*
    Change the priority of an existing entry (found via
    array[page_number].heap_idx) and restore heap order
    (sift up or down as needed).
    */
    void update_priority(int page_number, int new_priority) {
        // TODO: implement
    }

    /*
    Remove the entry for `page_number` from an arbitrary position
    in the heap (found via array[page_number].heap_idx), not just
    the root. Trickier than pop_min: after swapping the entry to
    the end and popping it, whatever moved into its old slot may need
    to sift EITHER up or down -- you don't know which in advance, so
    it is safe to attempt both.
    */
    void remove_at(int page_number) {
        // TODO: implement
    }
};

// Priority-based cache with capacity N, over page numbers 0 .. M - 1.
class Cache {
public:
    int M;
    int N;
    std::vector<PageEntry> array;
    DLL cache;
    Heap heap;
    int cache_size;

    Cache(int m, int n)
        : M(m), N(n), array(m), heap(array), cache_size(0) {}

    /*
    Access `page_number`.

    - HIT (already cached): increase its priority by 1, update its
      heap entry to match. Return "HIT".
    - MISS (not cached): if the cache is full, evict a page first.
      Then insert this page with base priority 1. Return "MISS".
    */
    std::string access_page(int page_number) {
        // TODO: implement
        return "";
    }

    /*
    Evict the lowest-priority page currently in the cache. Pop it
    from the heap, unlink it from the DLL, and clear its
    PageEntry (node=nullptr, heap_idx=-1). Return the evicted
    page_number.

    Assumes the cache is non-empty when called.
    */
    int evict() {
        // TODO: implement
        return -1;
    }

    /*
    Explicitly remove `page_number` from the cache if present:
    unlink from the DLL, remove from the heap (heap.remove_at),
    and clear its PageEntry. If not present, do nothing.

    Return true if a page was removed, false if it was already
    absent.
    */
    bool remove_page(int page_number) {
        // TODO: implement
        return false;
    }

    // -----------------------------------------------------------
    // Given -- convenience helpers, do not modify.
    // -----------------------------------------------------------

    bool contains(int page_number) const {
        return array[page_number].node != nullptr;
    }

    int size() const {
        return cache_size;
    }
};

#endif // CACHE_H