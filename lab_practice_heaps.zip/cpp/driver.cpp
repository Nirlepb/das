// Use the following to test the code
//
// g++ -std=c++17 -O2 driver.cpp -o test_cache
// ./test_cache


#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <exception>

#include "cache.h"

int _PASS = 0;
int _FAIL = 0;

void check(bool condition, const std::string& description) {
    if (condition) {
        _PASS++;
        std::cout << "  [PASS] " << description << "\n";
    } else {
        _FAIL++;
        std::cout << "  [FAIL] " << description << "\n";
    }
}

std::vector<PageEntry> make_array(int M) {
    return std::vector<PageEntry>(M);
}

void run_block(const std::string& block_description, const std::function<void()>& fn) {
    try {
        fn();
    } catch (const std::exception& e) {
        _FAIL++;
        std::cout << "  [FAIL] " << block_description << " (raised " << e.what()
                  << " -- skipping remaining checks in this block)\n";
    } catch (...) {
        _FAIL++;
        std::cout << "  [FAIL] " << block_description
                  << " (raised unknown exception -- skipping remaining checks in this block)\n";
    }
}

// ---------------------------------------------------------------------
// Test 1: DLL, in isolation
// ---------------------------------------------------------------------
void test_dll() {
    std::cout << "\n=== Test 1: DLL (insert_at_tail / remove) ===\n";

    auto insert_block = []() {
        DLL dll;
        check(dll.head == nullptr && dll.tail == nullptr, "new DLL has head=tail=nullptr");

        DLLNode* n1 = new DLLNode(0, 1);
        dll.insert_at_tail(n1);
        check(dll.head == n1 && dll.tail == n1, "single insert: head and tail both point to it");

        DLL dll2;
        DLLNode* a1 = new DLLNode(0, 1);
        DLLNode* a2 = new DLLNode(1, 1);
        DLLNode* a3 = new DLLNode(2, 1);
        dll2.insert_at_tail(a1);
        dll2.insert_at_tail(a2);
        dll2.insert_at_tail(a3);

        std::vector<std::pair<int, int>> expected = {{0, 1}, {1, 1}, {2, 1}};
        check(dll2.as_list() == expected, "insert_at_tail preserves insertion order");
        check(dll2.head == a1 && dll2.tail == a3, "head/tail correct after three inserts");
        check(a1->prev == nullptr && a1->next == a2, "first node's links are correct");
        check(a2->prev == a1 && a2->next == a3, "middle node's links are correct");
        check(a3->prev == a2 && a3->next == nullptr, "last node's links are correct");
    };

    auto remove_middle_block = []() {
        DLL dll;
        DLLNode* n1 = new DLLNode(0, 1);
        DLLNode* n2 = new DLLNode(1, 1);
        DLLNode* n3 = new DLLNode(2, 1);
        dll.insert_at_tail(n1);
        dll.insert_at_tail(n2);
        dll.insert_at_tail(n3);

        dll.remove(n2);
        delete n2;
        std::vector<std::pair<int, int>> expected = {{0, 1}, {2, 1}};
        check(dll.as_list() == expected, "remove(middle node) updates list order");
        check(n1->next == n3 && n3->prev == n1, "remove(middle node) relinks its neighbors");
    };

    auto remove_head_block = []() {
        DLL dll;
        DLLNode* n1 = new DLLNode(0, 1);
        DLLNode* n2 = new DLLNode(1, 1);
        DLLNode* n3 = new DLLNode(2, 1);
        dll.insert_at_tail(n1);
        dll.insert_at_tail(n2);
        dll.insert_at_tail(n3);

        dll.remove(n2);
        delete n2;
        dll.remove(n1);
        delete n1;

        std::vector<std::pair<int, int>> expected = {{2, 1}};
        check(dll.as_list() == expected, "remove(head) updates list order");
        check(dll.head == n3 && n3->prev == nullptr, "remove(head) updates the head pointer");
    };

    auto remove_last_node_block = []() {
        DLL dll;
        DLLNode* n1 = new DLLNode(0, 1);
        dll.insert_at_tail(n1);
        dll.remove(n1);
        delete n1;
        check(dll.head == nullptr && dll.tail == nullptr, "removing the last remaining node empties the list");
    };

    auto remove_tail_block = []() {
        DLL dll2;
        DLLNode* a = new DLLNode(0, 1);
        DLLNode* b = new DLLNode(1, 1);
        dll2.insert_at_tail(a);
        dll2.insert_at_tail(b);
        dll2.remove(b);
        delete b;

        check(dll2.tail == a && a->next == nullptr, "remove(tail) updates the tail pointer");
        check(dll2.head == a, "remove(tail) leaves head untouched");
    };

    run_block("insert_at_tail basics", insert_block);
    run_block("remove(middle node)", remove_middle_block);
    run_block("remove(head)", remove_head_block);
    run_block("remove(the only node)", remove_last_node_block);
    run_block("remove(tail)", remove_tail_block);
}

// ---------------------------------------------------------------------
// Test 2: Heap, in isolation
// ---------------------------------------------------------------------
bool _heap_property_ok(const Heap& heap) {
    int n = static_cast<int>(heap.data.size());
    for (int i = 0; i < n; ++i) {
        int l = 2 * i + 1;
        int r = 2 * i + 2;
        if (l < n && heap._key(l) < heap._key(i)) return false;
        if (r < n && heap._key(r) < heap._key(i)) return false;
    }
    return true;
}

bool _heap_idx_consistent(const Heap& heap) {
    for (size_t i = 0; i < heap.data.size(); ++i) {
        int page_number = heap.data[i].second;
        if (heap.array[page_number].heap_idx != static_cast<int>(i)) return false;
    }
    return true;
}

void _test_heap_random_stress(int num_trials = 100, int ops_per_trial = 40, unsigned int seed = 7) {
    std::mt19937 rng(seed);
    int mismatches = 0;
    int M = 12;

    for (int trial = 0; trial < num_trials; ++trial) {
        auto array = make_array(M);
        Heap heap(array);
        std::map<int, int> oracle;

        for (int op_i = 0; op_i < ops_per_trial; ++op_i) {
            int pn = rng() % M;
            double op = std::generate_canonical<double, 10>(rng);

            if (oracle.find(pn) == oracle.end()) {
                int pr = (rng() % 20) + 1;
                heap.push(pn, pr);
                oracle[pn] = pr;
            } else if (op < 0.4) {
                int new_pr = (rng() % 20) + 1;
                heap.update_priority(pn, new_pr);
                oracle[pn] = new_pr;
            } else if (op < 0.7) {
                heap.remove_at(pn);
                oracle.erase(pn);
            } else {
                if (!heap.data.empty()) {
                    auto [got_pr, got_pn] = heap.pop_min();
                    
                    int exp_pn = -1;
                    int exp_pr = 1e9;
                    for (const auto& kv : oracle) {
                        if (kv.second < exp_pr || (kv.second == exp_pr && kv.first < exp_pn)) {
                            exp_pr = kv.second;
                            exp_pn = kv.first;
                        }
                    }

                    if (got_pr != exp_pr || got_pn != exp_pn) {
                        mismatches++;
                        std::cout << "  [FAIL] trial " << trial << ": pop_min -> ("
                                  << got_pr << "," << got_pn << "), expected ("
                                  << exp_pr << "," << exp_pn << ")\n";
                        break;
                    }
                    oracle.erase(exp_pn);
                }
            }

            if (!_heap_property_ok(heap)) {
                mismatches++;
                std::cout << "  [FAIL] trial " << trial << ": heap property violated\n";
                break;
            }
            if (!_heap_idx_consistent(heap)) {
                mismatches++;
                std::cout << "  [FAIL] trial " << trial << ": heap_idx inconsistent with array\n";
                break;
            }
            std::set<int> heap_pns;
            for (const auto& item : heap.data) heap_pns.insert(item.second);
            std::set<int> oracle_pns;
            for (const auto& kv : oracle) oracle_pns.insert(kv.first);

            if (heap_pns != oracle_pns) {
                mismatches++;
                std::cout << "  [FAIL] trial " << trial << ": heap contents don't match oracle keys\n";
                break;
            }
        }
        if (mismatches > 0) break;
    }

    check(mismatches == 0, std::to_string(num_trials) + " random heap trials all match the reference behavior");
}

void test_heap() {
    std::cout << "\n=== Test 2: Heap (push / pop_min / update_priority / remove_at) ===\n";

    auto push_and_pop_min_block = []() {
        auto array = make_array(8);
        Heap heap(array);
        std::vector<std::pair<int, int>> inputs = {{0, 5}, {1, 3}, {2, 3}, {3, 7}, {4, 1}};
        for (auto& p : inputs) heap.push(p.first, p.second);

        check(_heap_property_ok(heap), "heap property holds after several pushes");
        check(_heap_idx_consistent(heap), "array[].heap_idx matches each entry's position after pushes");

        auto [pr, pn] = heap.pop_min();
        check(pr == 1 && pn == 4, "pop_min returns the lowest-priority entry first");
        check(array[4].heap_idx == -1, "popped entry's heap_idx is reset to -1");
        check(_heap_property_ok(heap), "heap property holds after pop_min");
        check(_heap_idx_consistent(heap), "heap_idx values stay consistent after pop_min");
    };

    auto tie_break_block = []() {
        auto array = make_array(5);
        Heap heap(array);
        heap.push(3, 2);
        heap.push(0, 2);
        heap.push(2, 2);
        auto [pr, pn] = heap.pop_min();
        check(pr == 2 && pn == 0, "tie-break: equal priority pops smaller page_number first");
    };

    auto update_priority_decrease_block = []() {
        auto array = make_array(6);
        Heap heap(array);
        for (int i = 0; i < 6; ++i) heap.push(i, 10);
        heap.update_priority(5, 1);
        check(_heap_property_ok(heap), "heap property holds after update_priority decreases a leaf");
        auto [pr, pn] = heap.pop_min();
        check(pr == 1 && pn == 5, "a decreased priority correctly bubbles up to the root");
    };

    auto update_priority_increase_block = []() {
        auto array = make_array(4);
        Heap heap(array);
        heap.push(0, 1);
        heap.push(1, 2);
        heap.push(2, 3);
        heap.push(3, 4);
        heap.update_priority(0, 100);
        check(_heap_property_ok(heap), "heap property holds after update_priority increases the root");
        auto [pr, pn] = heap.pop_min();
        check(pr == 2 && pn == 1, "an increased priority correctly sinks away from the root");
    };

    auto remove_at_internal_block = []() {
        auto array = make_array(7);
        Heap heap(array);
        for (int i = 0; i < 7; ++i) heap.push(i, i + 1);
        heap.remove_at(3);
        check(array[3].heap_idx == -1, "remove_at clears the removed entry's heap_idx");
        check(_heap_property_ok(heap), "heap property holds after remove_at on an internal node");
        check(_heap_idx_consistent(heap), "heap_idx values stay consistent after remove_at");

        bool not_found = std::all_of(heap.data.begin(), heap.data.end(), [](const std::pair<int, int>& p) {
            return p.second != 3;
        });
        check(heap.data.size() == 6 && not_found, "remove_at removes exactly the target entry and no other");
    };

    auto remove_at_last_slot_block = []() {
        auto array = make_array(3);
        Heap heap(array);
        heap.push(0, 1);
        heap.push(1, 2);
        heap.push(2, 3);
        heap.remove_at(2);
        check(heap.data.size() == 2 && _heap_property_ok(heap), "remove_at on the last heap slot works");
    };

    run_block("push / pop_min basics", push_and_pop_min_block);
    run_block("pop_min tie-break", tie_break_block);
    run_block("update_priority (decrease)", update_priority_decrease_block);
    run_block("update_priority (increase)", update_priority_increase_block);
    run_block("remove_at (internal node)", remove_at_internal_block);
    run_block("remove_at (last slot)", remove_at_last_slot_block);
    run_block("randomized heap stress test", []() { _test_heap_random_stress(); });
}

// ---------------------------------------------------------------------
// Test 3: Cache -- fixed trace
// ---------------------------------------------------------------------
void test_fixed_trace() {
    std::cout << "\n=== Test 3: Cache fixed trace (M=6, N=3) ===\n";
    Cache cache(6, 3);

    struct Step {
        std::string type;
        int pn;
        std::string exp_access;
        bool exp_remove;
    };

    std::vector<Step> steps = {
        {"access", 0, "MISS", false},
        {"access", 1, "MISS", false},
        {"access", 2, "MISS", false},
        {"access", 0, "HIT", false},
        {"access", 3, "MISS", false},
        {"access", 1, "MISS", false},
        {"remove", 2, "", false}
    };

    for (const auto& step : steps) {
        if (step.type == "access") {
            std::string result = cache.access_page(step.pn);
            check(result == step.exp_access, "accessPage(" + std::to_string(step.pn) + ") -> " + result + " (expected " + step.exp_access + ")");
        } else {
            bool result = cache.remove_page(step.pn);
            check(result == step.exp_remove, "removePage(" + std::to_string(step.pn) + ") -> " + (result ? "true" : "false"));
        }
    }

    check(cache.size() == 3, "cache size after trace is " + std::to_string(cache.size()) + " (expected 3)");
    check(cache.contains(0) && cache.contains(3) && cache.contains(1), "cache contains pages {0, 3, 1} after trace");
    check(!cache.contains(2) && !cache.contains(4) && !cache.contains(5), "cache does not contain pages {2, 4, 5} after trace");
}

// ---------------------------------------------------------------------
// Test 4: Cache -- edge cases
// ---------------------------------------------------------------------
void test_edge_cases() {
    std::cout << "\n=== Test 4: Cache edge cases ===\n";

    auto remove_never_accessed_block = []() {
        Cache cache(5, 2);
        check(cache.remove_page(2) == false, "removePage on a never-accessed page returns False");
    };

    auto size_at_capacity_block = []() {
        Cache cache(5, 2);
        cache.access_page(0);
        cache.access_page(1);
        check(cache.size() == 2, "cache size is exactly N after filling to capacity");
    };

    auto evict_tie_break_block = []() {
        Cache cache(5, 2);
        cache.access_page(3);
        cache.access_page(0);
        int victim = cache.evict();
        check(victim == 0, "tie-break evicts smaller pageID first (evicted " + std::to_string(victim) + ", expected 0)");
    };

    auto remove_then_reaccess_block = []() {
        Cache cache(5, 2);
        cache.access_page(0);
        cache.remove_page(0);
        std::string result = cache.access_page(0);
        check(result == "MISS", "re-accessing a removed page is a MISS, not a HIT");
        check(cache.contains(0), "page is back in the cache after re-access");
    };

    auto remove_non_root_block = []() {
        Cache cache(5, 3);
        cache.access_page(0);
        cache.access_page(1);
        cache.access_page(2);
        cache.access_page(1);
        bool removed = cache.remove_page(1);
        check(removed == true, "removePage removes a non-root page correctly");
        check(!cache.contains(1), "page 1 is gone after removePage");
        check(cache.contains(0) && cache.contains(2), "pages 0 and 2 are unaffected by removePage(1)");
    };

    run_block("removePage on never-accessed page", remove_never_accessed_block);
    run_block("cache size at capacity", size_at_capacity_block);
    run_block("evict tie-break", evict_tie_break_block);
    run_block("remove then re-access", remove_then_reaccess_block);
    run_block("removePage on a non-root page", remove_non_root_block);
}

// ---------------------------------------------------------------------
// Test 5: Cache -- randomized stress test against reference model
// ---------------------------------------------------------------------
class BruteForceCache {
public:
    int M;
    int N;
    std::map<int, int> cached;

    BruteForceCache(int m, int n) : M(m), N(n) {}

    std::string access_page(int page_number) {
        if (cached.find(page_number) != cached.end()) {
            cached[page_number]++;
            return "HIT";
        }
        if (static_cast<int>(cached.size()) == N) {
            evict();
        }
        cached[page_number] = 1;
        return "MISS";
    }

    int evict() {
        int victim = -1;
        int min_pr = 1e9;

        for (const auto& kv : cached) {
            if (kv.second < min_pr || (kv.second == min_pr && kv.first < victim)) {
                min_pr = kv.second;
                victim = kv.first;
            }
        }

        cached.erase(victim);
        return victim;
    }

    bool remove_page(int page_number) {
        if (cached.find(page_number) != cached.end()) {
            cached.erase(page_number);
            return true;
        }
        return false;
    }

    bool contains(int page_number) const {
        return cached.find(page_number) != cached.end();
    }

    int size() const {
        return static_cast<int>(cached.size());
    }
};

void test_random_stress(int num_trials = 200, int ops_per_trial = 60, unsigned int seed = 42) {
    std::cout << "\n=== Test 5: Cache randomized stress test (" << num_trials
              << " trials x " << ops_per_trial << " ops) ===\n";
    std::mt19937 rng(seed);
    int mismatches = 0;

    for (int trial = 0; trial < num_trials; ++trial) {
        int M = (rng() % 7) + 4;        // [4, 10]
        int N = (rng() % (M - 2)) + 2;  // [2, M-1]
        Cache cache(M, N);
        BruteForceCache oracle(M, N);

        try {
            for (int op_i = 0; op_i < ops_per_trial; ++op_i) {
                int page_number = rng() % M;
                double prob = std::generate_canonical<double, 10>(rng);

                if (prob < 0.8) {
                    std::string r1 = cache.access_page(page_number);
                    std::string r2 = oracle.access_page(page_number);
                    if (r1 != r2) {
                        mismatches++;
                        std::cout << "  [FAIL] trial " << trial << ": accessPage(" << page_number
                                  << ") -> " << r1 << ", expected " << r2 << "\n";
                        break;
                    }
                } else {
                    bool r1 = cache.remove_page(page_number);
                    bool r2 = oracle.remove_page(page_number);
                    if (r1 != r2) {
                        mismatches++;
                        std::cout << "  [FAIL] trial " << trial << ": removePage(" << page_number
                                  << ") -> " << (r1 ? "true" : "false") << ", expected "
                                  << (r2 ? "true" : "false") << "\n";
                        break;
                    }
                }

                if (cache.size() != oracle.size()) {
                    mismatches++;
                    std::cout << "  [FAIL] trial " << trial << ": size " << cache.size()
                              << ", expected " << oracle.size() << "\n";
                    break;
                }

                bool mismatch_found = false;
                for (int pn = 0; pn < M; ++pn) {
                    if (cache.contains(pn) != oracle.contains(pn)) {
                        mismatches++;
                        std::cout << "  [FAIL] trial " << trial << ": contains(" << pn << ") mismatch\n";
                        mismatch_found = true;
                        break;
                    }
                }
                if (mismatch_found) break;
            }
        } catch (const std::exception& e) {
            mismatches++;
            std::cout << "  [FAIL] trial " << trial << ": raised exception: " << e.what() << "\n";
            continue;
        }

        if (mismatches > 0) break;
    }

    check(mismatches == 0, std::to_string(num_trials) + " random trials all match the reference implementation");
}

int main() {
    run_block("Test 1: DLL", test_dll);
    run_block("Test 2: Heap", test_heap);
    run_block("Test 3: Cache fixed trace", test_fixed_trace);
    run_block("Test 4: Cache edge cases", test_edge_cases);
    run_block("Test 5: Cache randomized stress test", []() { test_random_stress(); });

    std::cout << "\n==================================================\n";
    std::cout << "TOTAL: " << _PASS << " passed, " << _FAIL << " failed\n";
    std::cout << "==================================================\n";

    return 0;
}