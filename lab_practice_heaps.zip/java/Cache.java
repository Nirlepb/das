/**
 * 23CSE203 - Data Structures and Algorithms
 * Lab: Priority Cache Eviction
 *
 * Implement the TODO methods in DLL.java, Heap.java, and Cache.java.
 * Do not change class names, method signatures, or public member attributes.
 *
 * Page numbering: pages are numbered 0 .. M - 1. Every lookup by pageNumber
 * must index directly into array[pageNumber].
 *
 * Tie-breaking rule: when two heap entries have equal priority, compare them as
 * (priority, pageNumber) -- the entry with the SMALLER pageNumber is "more evictable"
 * (compares smaller). This makes eviction order deterministic.
 */
public class Cache {

    public int M;
    public int N;
    public PageEntry[] array;
    public DLL cache;
    public Heap heap;
    public int cacheSize;

    public Cache(int M, int N) {
        this.M = M;
        this.N = N;
        this.array = new PageEntry[M];
        for (int i = 0; i < M; i++) {
            this.array[i] = new PageEntry();
        }
        this.cache = new DLL();
        this.heap = new Heap(this.array); // Heap gets reference to array
        this.cacheSize = 0;
    }

    /**
     * Access `pageNumber`.
     *
     * - HIT (already cached): increase its priority by 1, update its
     *   heap entry to match. Return "HIT".
     * - MISS (not cached): if the cache is full, evict a page first.
     *   Then insert this page with base priority 1. Return "MISS".
     */
    public String accessPage(int pageNumber) {
        // TODO: Implement
        return "";
    }

    /**
     * Evict the lowest-priority page currently in the cache. Pop it
     * from the heap, unlink it from the DLL, and clear its
     * PageEntry (node = null, heapIdx = -1). Return the evicted pageNumber.
     *
     * Assumes the cache is non-empty when called.
     */
    public int evict() {
        // TODO: Implement
        return -1;
    }

    /**
     * Explicitly remove `pageNumber` from the cache if present:
     * unlink from DLL, remove from heap (heap.removeAt),
     * and clear its PageEntry. If not present, do nothing.
     *
     * Return true if a page was removed, false if it was already absent.
     */
    public boolean removePage(int pageNumber) {
        // TODO: Implement
        return false;
    }

    // =========================================================================
    // Given -- convenience helpers, do not modify.
    // =========================================================================

    public boolean contains(int pageNumber) {
        return array[pageNumber].node != null;
    }

    public int size() {
        return cacheSize;
    }
}