import java.util.ArrayList;
import java.util.List;

/**
 * A plain doubly linked list. Implement insertAtTail and remove so
 * that both run in O(1), given a direct node reference (no searching).
 */
public class DLL {
    public DLLNode head;
    public DLLNode tail;

    public DLL() {
        this.head = null;
        this.tail = null;
    }

    /**
     * Insert `node` at the tail of the list. Must run in O(1).
     */
    public void insertAtTail(DLLNode node) {
        // TODO: Implement
    }

    /**
     * Remove `node` from the list, given a direct reference to it.
     * Must run in O(1). Correctly update head / tail if the removed
     * node was the head or tail.
     */
    public void remove(DLLNode node) {
        // TODO: Implement
    }

    /**
     * Given -- returns [(pageNumber, priority), ...] in list order.
     * Useful for debugging; the test file does not rely on this.
     */
    public List<int[]> asList() {
        List<int[]> out = new ArrayList<>();
        DLLNode cur = head;
        while (cur != null) {
            out.add(new int[]{cur.pageNumber, cur.priority});
            cur = cur.next;
        }
        return out;
    }
}