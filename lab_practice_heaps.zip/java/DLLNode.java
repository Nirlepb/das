/**
 * A node in the doubly linked list.
 * Given -- do not modify.
 */
public class DLLNode {
    public int pageNumber;
    public int priority;
    public DLLNode prev;
    public DLLNode next;

    public DLLNode(int pageNumber, int priority) {
        this.pageNumber = pageNumber;
        this.priority = priority;
        this.prev = null;
        this.next = null;
    }
}