import java.util.*;

/**
 * 23CSE203 - Data Structures and Algorithms
 * Lab: Priority Cache Eviction -- Driver File
 *
 * Execute using:
 *     javac *.java
 *     java Driver
 */
public class Driver {

    private static int _PASS = 0;
    private static int _FAIL = 0;

    private static void check(boolean condition, String description) {
        if (condition) {
            _PASS++;
            System.out.println("  [PASS] " + description);
        } else {
            _FAIL++;
            System.out.println("  [FAIL] " + description);
        }
    }

    private static PageEntry[] makeArray(int M) {
        PageEntry[] array = new PageEntry[M];
        for (int i = 0; i < M; i++) {
            array[i] = new PageEntry();
        }
        return array;
    }

    private static void runBlock(String blockDescription, Runnable fn) {
        try {
            fn.run();
        } catch (Exception e) {
            _FAIL++;
            System.out.println("  [FAIL] " + blockDescription +
                    " (raised " + e.getClass().getSimpleName() + ": " + e.getMessage() +
                    " -- skipping remaining checks in this block)");
            e.printStackTrace(System.out);
        }
    }

    // ---------------------------------------------------------------------
    // Test 1: DLL, in isolation
    // ---------------------------------------------------------------------
    public static void testDLL() {
        System.out.println("\n=== Test 1: DLL (insertAtTail / remove) ===");

        runBlock("insertAtTail basics", () -> {
            DLL dll = new DLL();
            check(dll.head == null && dll.tail == null, "new DLL has head=tail=null");

            DLLNode n1 = new DLLNode(0, 1);
            dll.insertAtTail(n1);
            check(dll.head == n1 && dll.tail == n1, "single insert: head and tail both point to it");

            DLL dll2 = new DLL();
            DLLNode a = new DLLNode(0, 1);
            DLLNode b = new DLLNode(1, 1);
            DLLNode c = new DLLNode(2, 1);
            dll2.insertAtTail(a);
            dll2.insertAtTail(b);
            dll2.insertAtTail(c);

            List<int[]> list = dll2.asList();
            boolean match = list.size() == 3 &&
                    list.get(0)[0] == 0 && list.get(1)[0] == 1 && list.get(2)[0] == 2;
            check(match, "insertAtTail preserves insertion order");
            check(dll2.head == a && dll2.tail == c, "head/tail correct after three inserts");
            check(a.prev == null && a.next == b, "first node's links are correct");
            check(b.prev == a && b.next == c, "middle node's links are correct");
            check(c.prev == b && c.next == null, "last node's links are correct");
        });

        runBlock("remove(middle node)", () -> {
            DLL dll = new DLL();
            DLLNode n1 = new DLLNode(0, 1);
            DLLNode n2 = new DLLNode(1, 1);
            DLLNode n3 = new DLLNode(2, 1);
            dll.insertAtTail(n1);
            dll.insertAtTail(n2);
            dll.insertAtTail(n3);

            dll.remove(n2);
            List<int[]> list = dll.asList();
            boolean match = list.size() == 2 && list.get(0)[0] == 0 && list.get(1)[0] == 2;
            check(match, "remove(middle node) updates list order");
            check(n1.next == n3 && n3.prev == n1, "remove(middle node) relinks its neighbors");
        });

        runBlock("remove(head)", () -> {
            DLL dll = new DLL();
            DLLNode n1 = new DLLNode(0, 1);
            DLLNode n2 = new DLLNode(1, 1);
            DLLNode n3 = new DLLNode(2, 1);
            dll.insertAtTail(n1);
            dll.insertAtTail(n2);
            dll.insertAtTail(n3);

            dll.remove(n2);
            dll.remove(n1);
            List<int[]> list = dll.asList();
            boolean match = list.size() == 1 && list.get(0)[0] == 2;
            check(match, "remove(head) updates list order");
            check(dll.head == n3 && n3.prev == null, "remove(head) updates the head pointer");
        });

        runBlock("remove(the only node)", () -> {
            DLL dll = new DLL();
            DLLNode n1 = new DLLNode(0, 1);
            dll.insertAtTail(n1);
            dll.remove(n1);
            check(dll.head == null && dll.tail == null, "removing the last remaining node empties the list");
        });

        runBlock("remove(tail)", () -> {
            DLL dll = new DLL();
            DLLNode a = new DLLNode(0, 1);
            DLLNode b = new DLLNode(1, 1);
            dll.insertAtTail(a);
            dll.insertAtTail(b);
            dll.remove(b);
            check(dll.tail == a && a.next == null, "remove(tail) updates the tail pointer");
            check(dll.head == a, "remove(tail) leaves head untouched");
        });
    }

    // ---------------------------------------------------------------------
    // Test 2: Heap, in isolation
    // ---------------------------------------------------------------------
    private static boolean heapPropertyOk(Heap heap) {
        int n = heap.data.size();
        for (int i = 0; i < n; i++) {
            int l = 2 * i + 1;
            int r = 2 * i + 2;
            if (l < n) {
                if (heap.data.get(l)[0] < heap.data.get(i)[0] ||
                   (heap.data.get(l)[0] == heap.data.get(i)[0] && heap.data.get(l)[1] < heap.data.get(i)[1])) {
                    return false;
                }
            }
            if (r < n) {
                if (heap.data.get(r)[0] < heap.data.get(i)[0] ||
                   (heap.data.get(r)[0] == heap.data.get(i)[0] && heap.data.get(r)[1] < heap.data.get(i)[1])) {
                    return false;
                }
            }
        }
        return true;
    }

    private static boolean heapIdxConsistent(Heap heap) {
        for (int i = 0; i < heap.data.size(); i++) {
            int pageNumber = heap.data.get(i)[1];
            if (heap.array[pageNumber].heapIdx != i) {
                return false;
            }
        }
        return true;
    }

    public static void testHeap() {
        System.out.println("\n=== Test 2: Heap (push / popMin / updatePriority / removeAt) ===");

        runBlock("push / popMin basics", () -> {
            PageEntry[] array = makeArray(8);
            Heap heap = new Heap(array);
            int[][] entries = {{0, 5}, {1, 3}, {2, 3}, {3, 7}, {4, 1}};
            for (int[] e : entries) {
                heap.push(e[0], e[1]);
            }
            check(heapPropertyOk(heap), "heap property holds after several pushes");
            check(heapIdxConsistent(heap), "array[].heapIdx matches each entry's position after pushes");

            int[] popped = heap.popMin();
            check(popped[0] == 1 && popped[1] == 4, "popMin returns the lowest-priority entry first (got (" + popped[0] + ", " + popped[1] + "))");
            check(array[4].heapIdx == -1, "popped entry's heapIdx is reset to -1");
            check(heapPropertyOk(heap), "heap property holds after popMin");
            check(heapIdxConsistent(heap), "heapIdx values stay consistent after popMin");
        });

        runBlock("popMin tie-break", () -> {
            PageEntry[] array = makeArray(5);
            Heap heap = new Heap(array);
            heap.push(3, 2);
            heap.push(0, 2);
            heap.push(2, 2);
            int[] popped = heap.popMin();
            check(popped[0] == 2 && popped[1] == 0, "tie-break: equal priority pops smaller pageNumber first");
        });

        runBlock("updatePriority (decrease)", () -> {
            PageEntry[] array = makeArray(6);
            Heap heap = new Heap(array);
            for (int i = 0; i < 6; i++) heap.push(i, 10);
            heap.updatePriority(5, 1);
            check(heapPropertyOk(heap), "heap property holds after updatePriority decreases a leaf");
            int[] popped = heap.popMin();
            check(popped[0] == 1 && popped[1] == 5, "a decreased priority correctly bubbles up to the root");
        });

        runBlock("updatePriority (increase)", () -> {
            PageEntry[] array = makeArray(4);
            Heap heap = new Heap(array);
            heap.push(0, 1); heap.push(1, 2); heap.push(2, 3); heap.push(3, 4);
            heap.updatePriority(0, 100);
            check(heapPropertyOk(heap), "heap property holds after updatePriority increases the root");
            int[] popped = heap.popMin();
            check(popped[0] == 2 && popped[1] == 1, "an increased priority correctly sinks away from the root");
        });

        runBlock("removeAt (internal node)", () -> {
            PageEntry[] array = makeArray(7);
            Heap heap = new Heap(array);
            for (int i = 0; i < 7; i++) heap.push(i, i + 1);
            heap.removeAt(3);
            check(array[3].heapIdx == -1, "removeAt clears the removed entry's heapIdx");
            check(heapPropertyOk(heap), "heap property holds after removeAt on an internal node");
            check(heapIdxConsistent(heap), "heapIdx values stay consistent after removeAt");

            boolean absent = true;
            for (int[] e : heap.data) {
                if (e[1] == 3) absent = false;
            }
            check(heap.data.size() == 6 && absent, "removeAt removes exactly the target entry and no other");
        });

        runBlock("removeAt (last slot)", () -> {
            PageEntry[] array = makeArray(3);
            Heap heap = new Heap(array);
            heap.push(0, 1); heap.push(1, 2); heap.push(2, 3);
            heap.removeAt(2);
            check(heap.data.size() == 2 && heapPropertyOk(heap), "removeAt on the last heap slot works");
        });

        runBlock("randomized heap stress test", () -> testHeapRandomStress(100, 40, 7));
    }

    private static void testHeapRandomStress(int numTrials, int opsPerTrial, long seed) {
        Random rng = new Random(seed);
        int mismatches = 0;
        int M = 12;

        for (int trial = 0; trial < numTrials; trial++) {
            PageEntry[] array = makeArray(M);
            Heap heap = new Heap(array);
            Map<Integer, Integer> oracle = new HashMap<>();

            for (int opIdx = 0; opIdx < opsPerTrial; opIdx++) {
                int pn = rng.nextInt(M);
                double op = rng.nextDouble();

                if (!oracle.containsKey(pn)) {
                    int pr = rng.nextInt(20) + 1;
                    heap.push(pn, pr);
                    oracle.put(pn, pr);
                } else if (op < 0.4) {
                    int newPr = rng.nextInt(20) + 1;
                    heap.updatePriority(pn, newPr);
                    oracle.put(pn, newPr);
                } else if (op < 0.7) {
                    heap.removeAt(pn);
                    oracle.remove(pn);
                } else {
                    if (!heap.data.isEmpty()) {
                        int[] got = heap.popMin();
                        int expPn = -1;
                        int expPr = Integer.MAX_VALUE;
                        for (Map.Entry<Integer, Integer> entry : oracle.entrySet()) {
                            int k = entry.getKey();
                            int v = entry.getValue();
                            if (v < expPr || (v == expPr && k < expPn)) {
                                expPr = v;
                                expPn = k;
                            }
                        }
                        if (got[0] != expPr || got[1] != expPn) {
                            mismatches++;
                            System.out.println("  [FAIL] trial " + trial + ": popMin -> (" + got[0] + "," + got[1] + "), expected (" + expPr + "," + expPn + ")");
                            break;
                        }
                        oracle.remove(expPn);
                    }
                }

                if (!heapPropertyOk(heap)) {
                    mismatches++;
                    System.out.println("  [FAIL] trial " + trial + ": heap property violated");
                    break;
                }
                if (!heapIdxConsistent(heap)) {
                    mismatches++;
                    System.out.println("  [FAIL] trial " + trial + ": heapIdx inconsistent with array");
                    break;
                }

                Set<Integer> heapPns = new HashSet<>();
                for (int[] e : heap.data) heapPns.add(e[1]);
                if (!heapPns.equals(oracle.keySet())) {
                    mismatches++;
                    System.out.println("  [FAIL] trial " + trial + ": heap contents don't match oracle keys");
                    break;
                }
            }
            if (mismatches > 0) break;
        }
        check(mismatches == 0, numTrials + " random heap trials all match reference behavior");
    }

    // ---------------------------------------------------------------------
    // Test 3: Cache -- fixed trace
    // ---------------------------------------------------------------------
    public static void testFixedTrace() {
        System.out.println("\n=== Test 3: Cache fixed trace (M=6, N=3) ===");
        Cache cache = new Cache(6, 3);

        String[][] steps = {
                {"access", "0", "MISS"},
                {"access", "1", "MISS"},
                {"access", "2", "MISS"},
                {"access", "0", "HIT"},
                {"access", "3", "MISS"},
                {"access", "1", "MISS"},
                {"remove", "2", "false"}
        };

        for (String[] step : steps) {
            String type = step[0];
            int pn = Integer.parseInt(step[1]);
            String expected = step[2];

            if (type.equals("access")) {
                String result = cache.accessPage(pn);
                check(result.equals(expected), "accessPage(" + pn + ") -> " + result + " (expected " + expected + ")");
            } else {
                boolean result = cache.removePage(pn);
                boolean expBool = Boolean.parseBoolean(expected);
                check(result == expBool, "removePage(" + pn + ") -> " + result + " (expected " + expected + ")");
            }
        }

        check(cache.size() == 3, "cache size after trace is " + cache.size() + " (expected 3)");
        check(cache.contains(0) && cache.contains(3) && cache.contains(1), "cache contains pages {0, 3, 1}");
        check(!cache.contains(2) && !cache.contains(4) && !cache.contains(5), "cache does not contain pages {2, 4, 5}");
    }

    // ---------------------------------------------------------------------
    // Test 4: Cache -- edge cases
    // ---------------------------------------------------------------------
    public static void testEdgeCases() {
        System.out.println("\n=== Test 4: Cache edge cases ===");

        runBlock("removePage on never-accessed page", () -> {
            Cache cache = new Cache(5, 2);
            check(!cache.removePage(2), "removePage on a never-accessed page returns false");
        });

        runBlock("cache size at capacity", () -> {
            Cache cache = new Cache(5, 2);
            cache.accessPage(0);
            cache.accessPage(1);
            check(cache.size() == 2, "cache size is exactly N after filling to capacity");
        });

        runBlock("evict tie-break", () -> {
            Cache cache = new Cache(5, 2);
            cache.accessPage(3);
            cache.accessPage(0);
            int victim = cache.evict();
            check(victim == 0, "tie-break evicts smaller pageID first (evicted " + victim + ", expected 0)");
        });

        runBlock("remove then re-access", () -> {
            Cache cache = new Cache(5, 2);
            cache.accessPage(0);
            cache.removePage(0);
            String result = cache.accessPage(0);
            check(result.equals("MISS"), "re-accessing a removed page is a MISS, not a HIT");
            check(cache.contains(0), "page is back in the cache after re-access");
        });

        runBlock("removePage on a non-root page", () -> {
            Cache cache = new Cache(5, 3);
            cache.accessPage(0);
            cache.accessPage(1);
            cache.accessPage(2);
            cache.accessPage(1);
            boolean removed = cache.removePage(1);
            check(removed, "removePage removes a non-root page correctly");
            check(!cache.contains(1), "page 1 is gone after removePage");
            check(cache.contains(0) && cache.contains(2), "pages 0 and 2 are unaffected by removePage(1)");
        });
    }

    // ---------------------------------------------------------------------
    // Test 5: Cache -- randomized stress test against a reference implementation
    // ---------------------------------------------------------------------
    private static class BruteForceCache {
        int M, N;
        Map<Integer, Integer> cached = new HashMap<>();

        public BruteForceCache(int M, int N) {
            this.M = M;
            this.N = N;
        }

        public String accessPage(int pageNumber) {
            if (cached.containsKey(pageNumber)) {
                cached.put(pageNumber, cached.get(pageNumber) + 1);
                return "HIT";
            }
            if (cached.size() == N) {
                evict();
            }
            cached.put(pageNumber, 1);
            return "MISS";
        }

        public int evict() {
            int victim = -1;
            int minPr = Integer.MAX_VALUE;
            for (Map.Entry<Integer, Integer> entry : cached.entrySet()) {
                int k = entry.getKey();
                int v = entry.getValue();
                if (v < minPr || (v == minPr && k < victim)) {
                    minPr = v;
                    victim = k;
                }
            }
            cached.remove(victim);
            return victim;
        }

        public boolean removePage(int pageNumber) {
            if (cached.containsKey(pageNumber)) {
                cached.remove(pageNumber);
                return true;
            }
            return false;
        }

        public boolean contains(int pageNumber) {
            return cached.containsKey(pageNumber);
        }

        public int size() {
            return cached.size();
        }
    }

    public static void testRandomStress(int numTrials, int opsPerTrial, long seed) {
        System.out.println("\n=== Test 5: Cache randomized stress test (" + numTrials + " trials x " + opsPerTrial + " ops) ===");
        Random rng = new Random(seed);
        int mismatches = 0;

        for (int trial = 0; trial < numTrials; trial++) {
            int M = rng.nextInt(7) + 4; // 4 to 10
            int N = rng.nextInt(M - 2) + 2; // 2 to M-1
            Cache cache = new Cache(M, N);
            BruteForceCache oracle = new BruteForceCache(M, N);

            try {
                for (int opIdx = 0; opIdx < opsPerTrial; opIdx++) {
                    int pageNumber = rng.nextInt(M);
                    if (rng.nextDouble() < 0.8) {
                        String r1 = cache.accessPage(pageNumber);
                        String r2 = oracle.accessPage(pageNumber);
                        if (!r1.equals(r2)) {
                            mismatches++;
                            System.out.println("  [FAIL] trial " + trial + ": accessPage(" + pageNumber + ") -> " + r1 + ", expected " + r2);
                            break;
                        }
                    } else {
                        boolean r1 = cache.removePage(pageNumber);
                        boolean r2 = oracle.removePage(pageNumber);
                        if (r1 != r2) {
                            mismatches++;
                            System.out.println("  [FAIL] trial " + trial + ": removePage(" + pageNumber + ") -> " + r1 + ", expected " + r2);
                            break;
                        }
                    }

                    if (cache.size() != oracle.size()) {
                        mismatches++;
                        System.out.println("  [FAIL] trial " + trial + ": size " + cache.size() + ", expected " + oracle.size());
                        break;
                    }

                    boolean mismatchFound = false;
                    for (int pn = 0; pn < M; pn++) {
                        if (cache.contains(pn) != oracle.contains(pn)) {
                            mismatches++;
                            System.out.println("  [FAIL] trial " + trial + ": contains(" + pn + ") mismatch");
                            mismatchFound = true;
                            break;
                        }
                    }
                    if (mismatchFound) break;
                }
            } catch (Exception e) {
                mismatches++;
                System.out.println("  [FAIL] trial " + trial + ": raised " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            if (mismatches > 0) break;
        }

        check(mismatches == 0, numTrials + " random trials all match the reference implementation");
    }

    public static void main(String[] args) {
        runBlock("Test 1: DLL", Driver::testDLL);
        runBlock("Test 2: Heap", Driver::testHeap);
        runBlock("Test 3: Cache fixed trace", Driver::testFixedTrace);
        runBlock("Test 4: Cache edge cases", Driver::testEdgeCases);
        runBlock("Test 5: Cache randomized stress test", () -> testRandomStress(200, 60, 42));

        System.out.println("\n==================================================");
        System.out.println("TOTAL: " + _PASS + " passed, " + _FAIL + " failed");
        System.out.println("==================================================");
    }
}