import java.util.ArrayList;
import java.util.List;

/**
 * A min-heap over (priority, pageNumber) pairs, stored as dynamic lists
 * in data. Holds a reference to Cache's array so that whenever two entries
 * change position (in swap), it can update each entry's PageEntry.heapIdx
 * directly -- this is the ONLY place Heap is allowed to touch `array`.
 */
public class Heap {
    public List<int[]> data;   // Dynamic list of int[]{priority, pageNumber}
    public PageEntry[] array;  // Shared reference, NOT a copy

    public Heap(PageEntry[] array) {
        this.data = new ArrayList<>();
        this.array = array;
    }

    /**
     * Given -- returns priority and pageNumber at heap index `i`.
     */
    public int[] getKey(int i) {
        return data.get(i);
    }

    /**
     * Swap heap entries at indices i and j, and update
     * array[pageNumber].heapIdx for both affected pages.
     */
    private void swap(int i, int j) {
        // TODO: Implement
    }

    /**
     * Restore heap order by moving entry i upward as needed.
     */
    private void siftUp(int i) {
        // TODO: Implement
    }

    /**
     * Restore heap order by moving entry i downward as needed.
     */
    private void siftDown(int i) {
        // TODO: Implement
    }

    /**
     * Insert a new (priority, pageNumber) entry, and set
     * array[pageNumber].heapIdx accordingly.
     */
    public void push(int pageNumber, int priority) {
        // TODO: Implement
    }

    /**
     * Remove and return int[]{priority, pageNumber} at the root.
     * Whatever entry moves into the vacated slot must have its
     * heapIdx corrected. Assumes heap is non-empty.
     */
    public int[] popMin() {
        // TODO: Implement
        return null;
    }

    /**
     * Change the priority of an existing entry (found via
     * array[pageNumber].heapIdx) and restore heap order
     * (sift up or down as needed).
     */
    public void updatePriority(int pageNumber, int newPriority) {
        // TODO: Implement
    }

    /**
     * Remove the entry for `pageNumber` from an arbitrary position
     * in the heap (found via array[pageNumber].heapIdx).
     *
     * Trickier than popMin: after swapping the entry to the end and popping
     * it, whatever moved into its old slot may need to sift EITHER up or
     * down -- you don't know which in advance, so it is safe to attempt both.
     */
    public void removeAt(int pageNumber) {
        // TODO: Implement
    }
}