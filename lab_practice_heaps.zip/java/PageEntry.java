/**
 * One slot of Cache.array, indexed by pageNumber.
 * Given -- do not modify.
 */
public class PageEntry {
    public DLLNode node;   // Pointer to DLLNode | null if absent
    public int heapIdx;    // Index into Heap.data, or -1 if absent

    public PageEntry() {
        this.node = null;
        this.heapIdx = -1;
    }
}