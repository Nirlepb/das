"""
23CSE203 - Data Structures and Algorithms
Lab: Priority Cache Eviction

Implement the TODO methods below. Do not change class names, method
signatures, or attribute names already set up in __init__ -- the test
file depends on them.


Page numbering: pages are numbered 0 .. M - 1. The array
that backs the cache still uses ordinary 0-indexed Python lists, so
every lookup by page_number must use array[page_number].  


Tie-breaking rule: when two heap entries have equal priority, compare
them as the tuple (priority, page_number) -- the entry with the
SMALLER page_number is "more evictable" (compares smaller). This
makes eviction order deterministic and testable.
"""


class DLLNode:
    """A node in the doubly linked list. Given -- do not modify."""
    def __init__(self, page_number, priority):
        self.page_number = page_number
        self.priority = priority
        self.prev = None
        self.next = None


class DLL:
    """
    A plain doubly linked list. Implement insert_at_tail and remove so
    that both run in O(1), given a direct node reference (no
    searching).
    """
    def __init__(self):
        self.head = None
        self.tail = None

    def insert_at_tail(self, node):
        """Insert `node` at the tail of the list. Must run in O(1)."""
        # TODO: implement
        pass

    def remove(self, node):
        """
        Remove `node` from the list, given a direct reference to it.
        Must run in O(1). Correctly update self.head / self.tail if
        the removed node was the head or tail.
        """
        # TODO: implement
        pass

    def as_list(self):
        """Given -- returns [(page_number, priority), ...] in list
        order. Useful for debugging; the test file does not rely on
        this."""
        out = []
        cur = self.head
        while cur:
            out.append((cur.page_number, cur.priority))
            cur = cur.next
        return out


class PageEntry:
    """
    One slot of Cache.array, indexed by page_number.
    Given -- do not modify.
    """
    def __init__(self):
        self.node = None       # DLLNode | None
        self.heap_idx = -1     # index into Heap.data, or -1 if absent


class Heap:
    """
    A min-heap over (priority, page_number) pairs, stored as plain
    lists in self.data. Holds a reference to Cache's array so that
    whenever two entries change position (in _swap), it can update
    each entry's PageEntry.heap_idx directly -- this is the ONLY
    place Heap is allowed to touch `array`.
    """
    def __init__(self, array):
        self.data = []        # list of [priority, page_number]
        self.array = array    # shared reference, NOT a copy

    def _key(self, i):
        priority, page_number = self.data[i]
        return (priority, page_number)

    def _swap(self, i, j):
        """
        Swap heap entries at indices i and j, and update
        self.array[...].heap_idx for both affected pages.
        """
        # TODO: implement
        pass

    def _sift_up(self, i):
        """Restore heap order by moving entry i upward as needed."""
        # TODO: implement
        pass

    def _sift_down(self, i):
        """Restore heap order by moving entry i downward as needed."""
        # TODO: implement
        pass

    def push(self, page_number, priority):
        """
        Insert a new (priority, page_number) entry, and set
        self.array[page_number].heap_idx accordingly.
        """
        # TODO: implement
        pass

    def pop_min(self):
        """
        Remove and return (priority, page_number) at the root.
        Whatever entry moves into the vacated slot must have its
        heap_idx corrected. Assumes the heap is non-empty.
        """
        # TODO: implement
        pass

    def update_priority(self, page_number, new_priority):
        """
        Change the priority of an existing entry (found via
        self.array[page_number].heap_idx) and restore heap order
        (sift up or down as needed).
        """
        # TODO: implement
        pass

    def remove_at(self, page_number):
        """
        Remove the entry for `page_number` from an arbitrary position
        in the heap (found via self.array[page_number].heap_idx),
        not just the root. Trickier than pop_min: after swapping the
        entry to the end and popping it, whatever moved into its old
        slot may need to sift EITHER up or down -- you don't know
        which in advance, so it is safe to attempt both.
        """
        # TODO: implement
        pass


class Cache:
    """
    Priority-based cache with capacity N, over page numbers 0 .. M - 1.
    """

    def __init__(self, M, N):
        self.M = M
        self.N = N
        self.array = [PageEntry() for _ in range(M)]
        self.cache = DLL()
        self.heap = Heap(self.array)   # heap gets a reference to array at construction
        self.cache_size = 0

    def access_page(self, page_number):
        """
        Access `page_number`.

        - HIT (already cached): increase its priority by 1, update its
          heap entry to match. Return "HIT".
        - MISS (not cached): if the cache is full, evict a page first.
          Then insert this page with base priority 1. Return "MISS".
        """
        # TODO: implement
        pass

    def evict(self):
        """
        Evict the lowest-priority page currently in the cache. Pop it
        from the heap, unlink it from the DLL, and clear its
        PageEntry (node=None, heap_idx=-1). Return the evicted
        page_number.

        Assumes the cache is non-empty when called.
        """
        # TODO: implement
        pass

    def remove_page(self, page_number):
        """
        Explicitly remove `page_number` from the cache if present:
        unlink from the DLL, remove from the heap (heap.remove_at),
        and clear its PageEntry. If not present, do nothing.

        Return True if a page was removed, False if it was already
        absent.
        """
        # TODO: implement
        pass

    # -----------------------------------------------------------
    # Given -- convenience helpers, do not modify.
    # -----------------------------------------------------------

    def contains(self, page_number):
        return self.array[page_number].node is not None

    def size(self):
        return self.cache_size