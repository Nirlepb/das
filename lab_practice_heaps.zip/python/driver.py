"""
23CSE203 - Data Structures and Algorithms
Lab: Priority Cache Eviction -- Test / Driver File

Run this file directly:
    python3 test_cache.py

Do not modify this file. It imports your implementation from cache.py
and checks it in five stages, so you get feedback on which layer is
broken instead of one opaque failure at the end:
    1. DLL correctness (insert_at_tail / remove), in isolation.
    2. Heap correctness (push / pop_min / update_priority / remove_at),
       in isolation.
    3. Cache correctness: a fixed, hand-checkable trace.
    4. Cache correctness: edge cases.
    5. A randomized stress test of the whole Cache against a
       brute-force reference implementation.

Page numbers throughout are 0-indexed (0 .. M-1), matching cache.py.
"""

import random
import sys
import traceback


def _fail_to_import(explanation_lines):
    """
    Print a clean, single failure report and exit -- used when cache.py
    can't even be imported (syntax error, wrong names, exception at
    module load time, etc). Keeps the same 'TOTAL: X passed, Y failed'
    line other failures print, in case a script parses this output.
    """
    print("\n" + "=" * 50)
    print("[FATAL] cache.py could not be loaded -- no tests were run.")
    for line in explanation_lines:
        print(f"        {line}")
    print("=" * 50)
    print("\nTOTAL: 0 passed, 1 failed  (cache.py failed to import)")
    sys.exit(1)


try:
    from cache import Cache, DLL, DLLNode, Heap, PageEntry
except SyntaxError as e:
    lines = [f"{type(e).__name__}: {e.msg}"]
    if e.filename and e.lineno:
        lines.append(f'File "{e.filename}", line {e.lineno}')
        if e.text:
            pointer = ""
            if e.offset:
                pointer = " " * (e.offset - 1) + "^"
            lines.append(f"  {e.text.rstrip()}")
            if pointer:
                lines.append(f"  {pointer}")
    lines.append("Fix the syntax error above, then re-run this file.")
    _fail_to_import(lines)
except ImportError as e:
    _fail_to_import([
        f"ImportError: {e}",
        "Make sure cache.py defines exactly these names: "
        "Cache, DLL, DLLNode, Heap, PageEntry.",
    ])
except Exception as e:
    print("\n" + "=" * 50)
    print(f"[FATAL] cache.py raised {type(e).__name__} while being loaded (before any test ran):")
    print("=" * 50)
    traceback.print_exc()
    print(f"\nTOTAL: 0 passed, 1 failed  (cache.py failed to import)")
    sys.exit(1)

_PASS = 0
_FAIL = 0


def check(condition, description):
    global _PASS, _FAIL
    if condition:
        _PASS += 1
        print(f"  [PASS] {description}")
    else:
        _FAIL += 1
        print(f"  [FAIL] {description}")


def make_array(M):
    return [PageEntry() for _ in range(M)]


def run_block(block_description, fn):
    """
    Run fn(), which performs its own check() calls. If fn() raises (e.g.
    because an earlier TODO returns None instead of the real value), record
    ONE failure for the whole block and move on, instead of letting the
    exception crash the rest of the test suite. This way a broken DLL
    doesn't hide feedback about the Heap or Cache tests that follow.
    """
    global _FAIL
    try:
        fn()
    except Exception as e:
        _FAIL += 1
        print(f"  [FAIL] {block_description} "
              f"(raised {type(e).__name__}: {e} -- skipping remaining checks in this block)")


# ---------------------------------------------------------------------
# Test 1: DLL, in isolation
# ---------------------------------------------------------------------
def test_dll():
    print("\n=== Test 1: DLL (insert_at_tail / remove) ===")

    def build_three_node_dll():
        """Setup helper (no checks): a DLL with three nodes 0 -> 1 -> 2 appended in order."""
        dll = DLL()
        n1, n2, n3 = DLLNode(0, 1), DLLNode(1, 1), DLLNode(2, 1)
        dll.insert_at_tail(n1)
        dll.insert_at_tail(n2)
        dll.insert_at_tail(n3)
        return dll, n1, n2, n3

    def insert_block():
        dll = DLL()
        check(dll.head is None and dll.tail is None, "new DLL has head=tail=None")

        n1 = DLLNode(0, 1)
        dll.insert_at_tail(n1)
        check(dll.head is n1 and dll.tail is n1, "single insert: head and tail both point to it")

        dll, n1, n2, n3 = build_three_node_dll()
        check(dll.as_list() == [(0, 1), (1, 1), (2, 1)], "insert_at_tail preserves insertion order")
        check(dll.head is n1 and dll.tail is n3, "head/tail correct after three inserts")
        check(n1.prev is None and n1.next is n2, "first node's links are correct")
        check(n2.prev is n1 and n2.next is n3, "middle node's links are correct")
        check(n3.prev is n2 and n3.next is None, "last node's links are correct")

    def remove_middle_block():
        dll, n1, n2, n3 = build_three_node_dll()
        dll.remove(n2)
        check(dll.as_list() == [(0, 1), (2, 1)], "remove(middle node) updates list order")
        check(n1.next is n3 and n3.prev is n1, "remove(middle node) relinks its neighbors")

    def remove_head_block():
        dll, n1, n2, n3 = build_three_node_dll()
        dll.remove(n2)
        dll.remove(n1)
        check(dll.as_list() == [(2, 1)], "remove(head) updates list order")
        check(dll.head is n3 and n3.prev is None, "remove(head) updates the head pointer")

    def remove_last_node_block():
        dll = DLL()
        n1 = DLLNode(0, 1)
        dll.insert_at_tail(n1)
        dll.remove(n1)
        check(dll.head is None and dll.tail is None, "removing the last remaining node empties the list")

    def remove_tail_block():
        dll2 = DLL()
        a, b = DLLNode(0, 1), DLLNode(1, 1)
        dll2.insert_at_tail(a)
        dll2.insert_at_tail(b)
        dll2.remove(b)
        check(dll2.tail is a and a.next is None, "remove(tail) updates the tail pointer")
        check(dll2.head is a, "remove(tail) leaves head untouched")

    run_block("insert_at_tail basics", insert_block)
    run_block("remove(middle node)", remove_middle_block)
    run_block("remove(head)", remove_head_block)
    run_block("remove(the only node)", remove_last_node_block)
    run_block("remove(tail)", remove_tail_block)


# ---------------------------------------------------------------------
# Test 2: Heap, in isolation
# ---------------------------------------------------------------------
def _heap_property_ok(heap):
    n = len(heap.data)
    for i in range(n):
        l, r = 2 * i + 1, 2 * i + 2
        if l < n and heap._key(l) < heap._key(i):
            return False
        if r < n and heap._key(r) < heap._key(i):
            return False
    return True


def _heap_idx_consistent(heap):
    for i, (priority, page_number) in enumerate(heap.data):
        if heap.array[page_number].heap_idx != i:
            return False
    return True


def test_heap():
    print("\n=== Test 2: Heap (push / pop_min / update_priority / remove_at) ===")

    def push_and_pop_min_block():
        array = make_array(8)
        heap = Heap(array)
        for pn, pr in [(0, 5), (1, 3), (2, 3), (3, 7), (4, 1)]:
            heap.push(pn, pr)
        check(_heap_property_ok(heap), "heap property holds after several pushes")
        check(_heap_idx_consistent(heap), "array[].heap_idx matches each entry's position after pushes")

        pr, pn = heap.pop_min()
        check((pr, pn) == (1, 4), f"pop_min returns the lowest-priority entry first (got ({pr}, {pn}))")
        check(array[4].heap_idx == -1, "popped entry's heap_idx is reset to -1")
        check(_heap_property_ok(heap), "heap property holds after pop_min")
        check(_heap_idx_consistent(heap), "heap_idx values stay consistent after pop_min")

    def tie_break_block():
        array2 = make_array(5)
        heap2 = Heap(array2)
        heap2.push(3, 2)
        heap2.push(0, 2)
        heap2.push(2, 2)
        pr, pn = heap2.pop_min()
        check((pr, pn) == (2, 0),
              f"tie-break: equal priority pops smaller page_number first (got ({pr}, {pn}))")

    def update_priority_decrease_block():
        array3 = make_array(6)
        heap3 = Heap(array3)
        for pn, pr in [(0, 10), (1, 10), (2, 10), (3, 10), (4, 10), (5, 10)]:
            heap3.push(pn, pr)
        heap3.update_priority(5, 1)
        check(_heap_property_ok(heap3), "heap property holds after update_priority decreases a leaf")
        pr, pn = heap3.pop_min()
        check((pr, pn) == (1, 5), "a decreased priority correctly bubbles up to the root")

    def update_priority_increase_block():
        array4 = make_array(4)
        heap4 = Heap(array4)
        for pn, pr in [(0, 1), (1, 2), (2, 3), (3, 4)]:
            heap4.push(pn, pr)
        heap4.update_priority(0, 100)
        check(_heap_property_ok(heap4), "heap property holds after update_priority increases the root")
        pr, pn = heap4.pop_min()
        check((pr, pn) == (2, 1), "an increased priority correctly sinks away from the root")

    def remove_at_internal_block():
        array5 = make_array(7)
        heap5 = Heap(array5)
        for pn, pr in [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7)]:
            heap5.push(pn, pr)
        heap5.remove_at(3)
        check(array5[3].heap_idx == -1, "remove_at clears the removed entry's heap_idx")
        check(_heap_property_ok(heap5), "heap property holds after remove_at on an internal node")
        check(_heap_idx_consistent(heap5), "heap_idx values stay consistent after remove_at")
        check(
            len(heap5.data) == 6 and all(pn != 3 for _, pn in heap5.data),
            "remove_at removes exactly the target entry and no other",
        )

    def remove_at_last_slot_block():
        array6 = make_array(3)
        heap6 = Heap(array6)
        heap6.push(0, 1)
        heap6.push(1, 2)
        heap6.push(2, 3)
        heap6.remove_at(2)
        check(len(heap6.data) == 2 and _heap_property_ok(heap6), "remove_at on the last heap slot works")

    run_block("push / pop_min basics", push_and_pop_min_block)
    run_block("pop_min tie-break", tie_break_block)
    run_block("update_priority (decrease)", update_priority_decrease_block)
    run_block("update_priority (increase)", update_priority_increase_block)
    run_block("remove_at (internal node)", remove_at_internal_block)
    run_block("remove_at (last slot)", remove_at_last_slot_block)
    run_block("randomized heap stress test", _test_heap_random_stress)


def _test_heap_random_stress(num_trials=100, ops_per_trial=40, seed=7):
    rng = random.Random(seed)
    mismatches = 0
    M = 12

    for trial in range(num_trials):
        array = make_array(M)
        heap = Heap(array)
        oracle = {}  # page_number -> priority

        for _ in range(ops_per_trial):
            pn = rng.randint(0, M - 1)
            op = rng.random()

            if pn not in oracle:
                pr = rng.randint(1, 20)
                heap.push(pn, pr)
                oracle[pn] = pr
            elif op < 0.4:
                new_pr = rng.randint(1, 20)
                heap.update_priority(pn, new_pr)
                oracle[pn] = new_pr
            elif op < 0.7:
                heap.remove_at(pn)
                del oracle[pn]
            else:
                if heap.data:
                    got_pr, got_pn = heap.pop_min()
                    exp_pn = min(oracle.items(), key=lambda kv: (kv[1], kv[0]))[0]
                    exp_pr = oracle[exp_pn]
                    if (got_pr, got_pn) != (exp_pr, exp_pn):
                        mismatches += 1
                        print(f"  [FAIL] trial {trial}: pop_min -> ({got_pr},{got_pn}), "
                              f"expected ({exp_pr},{exp_pn})")
                        break
                    del oracle[exp_pn]

            if not _heap_property_ok(heap):
                mismatches += 1
                print(f"  [FAIL] trial {trial}: heap property violated")
                break
            if not _heap_idx_consistent(heap):
                mismatches += 1
                print(f"  [FAIL] trial {trial}: heap_idx inconsistent with array")
                break
            if {pn for _, pn in heap.data} != set(oracle.keys()):
                mismatches += 1
                print(f"  [FAIL] trial {trial}: heap contents don't match oracle keys")
                break
        else:
            continue
        break

    check(mismatches == 0, f"{num_trials} random heap trials all match the reference behavior")


# ---------------------------------------------------------------------
# Test 3: Cache -- fixed trace
# ---------------------------------------------------------------------
def test_fixed_trace():
    print("\n=== Test 3: Cache fixed trace (M=6, N=3) ===")
    cache = Cache(M=6, N=3)

    steps = [
        ("access", 0, "MISS"),
        ("access", 1, "MISS"),
        ("access", 2, "MISS"),
        ("access", 0, "HIT"),
        ("access", 3, "MISS"),   # evicts page 1 (tie between 1,2 at priority 1 -> smaller pageID)
        ("access", 1, "MISS"),   # page 1 was evicted -> fresh miss, evicts page 2
        ("remove", 2, False),    # page 2 already evicted -> no-op
    ]

    for step in steps:
        if step[0] == "access":
            _, pn, expected = step
            result = cache.access_page(pn)
            check(result == expected, f"accessPage({pn}) -> {result} (expected {expected})")
        else:
            _, pn, expected = step
            result = cache.remove_page(pn)
            check(result == expected, f"removePage({pn}) -> {result} (expected {expected})")

    check(cache.size() == 3, f"cache size after trace is {cache.size()} (expected 3)")
    check(cache.contains(0) and cache.contains(3) and cache.contains(1),
          "cache contains pages {0, 3, 1} after trace")
    check(not cache.contains(2) and not cache.contains(4) and not cache.contains(5),
          "cache does not contain pages {2, 4, 5} after trace")


# ---------------------------------------------------------------------
# Test 4: Cache -- edge cases
# ---------------------------------------------------------------------
def test_edge_cases():
    print("\n=== Test 4: Cache edge cases ===")

    def remove_never_accessed_block():
        cache = Cache(M=5, N=2)
        check(cache.remove_page(2) == False, "removePage on a never-accessed page returns False")

    def size_at_capacity_block():
        cache = Cache(M=5, N=2)
        cache.access_page(0)
        cache.access_page(1)
        check(cache.size() == 2, "cache size is exactly N after filling to capacity")

    def evict_tie_break_block():
        # tie-break: two pages with equal priority, smaller page_number evicted first
        cache = Cache(M=5, N=2)
        cache.access_page(3)   # priority 1
        cache.access_page(0)   # priority 1, tied with page 3
        victim = cache.evict()
        check(victim == 0, f"tie-break evicts smaller pageID first (evicted {victim}, expected 0)")

    def remove_then_reaccess_block():
        # remove then re-access the same page -- should be a fresh miss
        cache = Cache(M=5, N=2)
        cache.access_page(0)
        cache.remove_page(0)
        result = cache.access_page(0)
        check(result == "MISS", "re-accessing a removed page is a MISS, not a HIT")
        check(cache.contains(0), "page is back in the cache after re-access")

    def remove_non_root_block():
        # removePage on a page NOT at the heap root (exercises remove_at, not just pop_min)
        cache = Cache(M=5, N=3)
        cache.access_page(0)   # priority 1
        cache.access_page(1)   # priority 1
        cache.access_page(2)   # priority 1
        cache.access_page(1)   # priority 2, no longer the min -> pushed away from root
        removed = cache.remove_page(1)
        check(removed == True, "removePage removes a non-root page correctly")
        check(not cache.contains(1), "page 1 is gone after removePage")
        check(cache.contains(0) and cache.contains(2), "pages 0 and 2 are unaffected by removePage(1)")

    run_block("removePage on never-accessed page", remove_never_accessed_block)
    run_block("cache size at capacity", size_at_capacity_block)
    run_block("evict tie-break", evict_tie_break_block)
    run_block("remove then re-access", remove_then_reaccess_block)
    run_block("removePage on a non-root page", remove_non_root_block)


# ---------------------------------------------------------------------
# Test 5: Cache -- randomized stress test against a brute-force oracle
# ---------------------------------------------------------------------
class BruteForceCache:
    def __init__(self, M, N):
        self.M = M
        self.N = N
        self.cached = {}  # page_number -> priority

    def access_page(self, page_number):
        if page_number in self.cached:
            self.cached[page_number] += 1
            return "HIT"
        if len(self.cached) == self.N:
            self.evict()
        self.cached[page_number] = 1
        return "MISS"

    def evict(self):
        victim = min(self.cached.items(), key=lambda kv: (kv[1], kv[0]))[0]
        del self.cached[victim]
        return victim

    def remove_page(self, page_number):
        if page_number in self.cached:
            del self.cached[page_number]
            return True
        return False

    def contains(self, page_number):
        return page_number in self.cached

    def size(self):
        return len(self.cached)


def test_random_stress(num_trials=200, ops_per_trial=60, seed=42):
    print(f"\n=== Test 5: Cache randomized stress test ({num_trials} trials x {ops_per_trial} ops) ===")
    rng = random.Random(seed)
    mismatches = 0

    for trial in range(num_trials):
        M = rng.randint(4, 10)
        N = rng.randint(2, M - 1)
        cache = Cache(M, N)
        oracle = BruteForceCache(M, N)

        try:
            for _ in range(ops_per_trial):
                page_number = rng.randint(0, M - 1)   # 0-indexed
                if rng.random() < 0.8:
                    r1 = cache.access_page(page_number)
                    r2 = oracle.access_page(page_number)
                    if r1 != r2:
                        mismatches += 1
                        print(f"  [FAIL] trial {trial}: accessPage({page_number}) -> {r1}, expected {r2}")
                        break
                else:
                    r1 = cache.remove_page(page_number)
                    r2 = oracle.remove_page(page_number)
                    if r1 != r2:
                        mismatches += 1
                        print(f"  [FAIL] trial {trial}: removePage({page_number}) -> {r1}, expected {r2}")
                        break

                if cache.size() != oracle.size():
                    mismatches += 1
                    print(f"  [FAIL] trial {trial}: size {cache.size()}, expected {oracle.size()}")
                    break

                mismatch_found = False
                for pn in range(0, M):
                    if cache.contains(pn) != oracle.contains(pn):
                        mismatches += 1
                        print(f"  [FAIL] trial {trial}: contains({pn}) mismatch")
                        mismatch_found = True
                        break
                if mismatch_found:
                    break
        except Exception as e:
            mismatches += 1
            print(f"  [FAIL] trial {trial}: raised {type(e).__name__}: {e}")
            continue

    check(mismatches == 0, f"{num_trials} random trials all match the reference implementation")


if __name__ == "__main__":
    run_block("Test 1: DLL", test_dll)
    run_block("Test 2: Heap", test_heap)
    run_block("Test 3: Cache fixed trace", test_fixed_trace)
    run_block("Test 4: Cache edge cases", test_edge_cases)
    run_block("Test 5: Cache randomized stress test", test_random_stress)

    print(f"\n{'='*50}")
    print(f"TOTAL: {_PASS} passed, {_FAIL} failed")
    print(f"{'='*50}")